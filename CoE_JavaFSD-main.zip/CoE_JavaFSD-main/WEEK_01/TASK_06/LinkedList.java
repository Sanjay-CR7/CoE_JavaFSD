public class LinkedList {
    static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;

    public void addNode(int data) {
        if (head == null) {
            head = new Node(data);
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = new Node(data);
        }
    }

    public void createCycle(int pos) {
        if (head == null || pos < 0) return;

        Node temp = head;
        Node cycleNode = null;
        int index = 0;

        while (temp.next != null) {
            if (index == pos) cycleNode = temp;
            temp = temp.next;
            index++;
        }

        if (cycleNode != null) temp.next = cycleNode;
    }

    public boolean hasCycle() {
        if (head == null || head.next == null) return false;

        Node slow = head;
        Node fast = head;

        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) return true;
        }
        return false;
    }

    public void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }
        System.out.println("null");
    }
}
